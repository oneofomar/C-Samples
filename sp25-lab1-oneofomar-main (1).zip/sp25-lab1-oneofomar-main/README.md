# CMPSC 311 Lab1
Please refer to the Lab1_ReadMe pdf for lab description and instructions.
